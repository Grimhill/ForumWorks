﻿CKEDITOR.plugins.setLang( 'spoiler', 'ru', {
	toolbar: 'Спойлер'
} );
