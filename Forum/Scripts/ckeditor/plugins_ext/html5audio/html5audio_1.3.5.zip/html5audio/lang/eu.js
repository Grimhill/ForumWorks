CKEDITOR.plugins.setLang( 'html5audio', 'eu', {
    button: 'Txertatu HTML5 audioa',
    title: 'HTML5 audioa',
    infoLabel: 'Audioaren informazioa',
    urlMissing: 'Audioaren URLak ezin du hutsik egon.',
    audioProperties: 'Audioaren propietateak',
    upload: 'Kargatu',
    btnUpload: 'Bidali zerbitzarira',
    advanced: 'Aurreratua',
    autoplay: 'Automatikoki erreproduzitu?',
    yes: 'Bai',
    no: 'Ez'
} );
